import React from 'react';
import ReactDOM from 'react-dom';
alert('It works');
const TodoList = (any) => {
   return (
       <ul>
           <li>{any.todo1}</li>
           <li>{any.todo2}</li>
           <li>{any.todo3}</li>
       </ul>
   )
}
ReactDOM.render(
   <TodoList todo1='Sign up for code review' todo2='Finsih TodoList component' todo3='Get Lost of practice'/>,
   document.getElementById('root'))


 


