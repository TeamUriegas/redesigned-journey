import React from 'react';
import ReactDOM from 'react-dom';
ReactDOM.render(
    <table>
  <tr>
    <th>Firstname</th>
    <th>Lastname</th>
  </tr>
  <tr>
    <td>Janet</td>
    <td>James</td>
  </tr>
  <tr>
    <td>John</td>
    <td>Jameson</td>
  </tr>
 </table>,
 document.getElementById('root')
 )
 


