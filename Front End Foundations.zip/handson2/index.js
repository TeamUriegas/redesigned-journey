import React from 'react';
import ReactDOM from 'react-dom';

const h1 = "Tips for breaking down a new concept";
const tip1 = "Many concepts can't be tackled all at once";
const tip2 = "Work with the parts you can understand";
const tip3 = "Take breaks to stay fresh";
const tip4 = "Develop a plan to learn the parts you don't know";
const tip5 = "Start with the parts that you know";
const tip6 = "Build new concepts on top";
ReactDOM.render(
<div>
<h1>{h1}</h1>
<ul>
<li>{tip1}</li>
<li>{tip2}</li>
<li>{tip3}</li>
<li>{tip4}</li>
<li>{tip5}</li>
<li>{tip6}</li>
</ul>
</div>,
document.getElementById('root')
);

 


